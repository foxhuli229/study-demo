import { Store, install } from './store'; //

// Vuex.Store  Vuex.install


export default {
    Store,
    install
}


// 这个文件是入口文件，核心就是导出所有写好的方法