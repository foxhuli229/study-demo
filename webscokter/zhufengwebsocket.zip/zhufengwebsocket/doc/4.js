let s = 0b01111111;
console.log(parseInt('1111111', 2));

console.log(parseInt('10000000', 2));